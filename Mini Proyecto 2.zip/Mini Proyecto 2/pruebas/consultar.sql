-- Generado por msqlc (MSQL -> PostgreSQL). No editar a mano.

SELECT name, price
FROM products
WHERE price > 100
ORDER BY price
LIMIT 5;
