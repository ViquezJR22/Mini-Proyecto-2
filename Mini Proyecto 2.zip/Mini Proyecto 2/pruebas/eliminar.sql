-- Generado por msqlc (MSQL -> PostgreSQL). No editar a mano.

DELETE FROM products WHERE name = 'Laptop';
