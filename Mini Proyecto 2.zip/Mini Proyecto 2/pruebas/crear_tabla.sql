-- Generado por msqlc (MSQL -> PostgreSQL). No editar a mano.

CREATE TABLE products (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name TEXT NOT NULL,
  price NUMERIC
);
