-- Generado por msqlc (MSQL -> PostgreSQL). No editar a mano.

UPDATE products
SET price = 900
WHERE name = 'Laptop';
