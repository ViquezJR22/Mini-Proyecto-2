-- Generado por msqlc (MSQL -> PostgreSQL). No editar a mano.

INSERT INTO products (name, price)
VALUES ('Laptop', 850);
