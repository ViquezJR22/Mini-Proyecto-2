"""Pruebas del compilador MSQL -> PostgreSQL.   Ejecutar:  python -m pytest -v"""
from pathlib import Path

import pytest

from msql import CompileError, compile_source

ROOT = Path(__file__).resolve().parent.parent
EXAMPLES = sorted((ROOT / "examples").glob("*.msql"))


def sql(src: str, **kw) -> str:
    return compile_source(src, header=False, **kw).sql.strip()


# ---- 1. Los 5 ejemplos de la sección 5 de la especificación -------------------------
def test_spec_make():
    assert sql("MAKE users (id id, name text, email text!, created time)") == (
        "CREATE TABLE users (\n"
        "  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,\n"
        "  name TEXT,\n"
        "  email TEXT NOT NULL,\n"
        "  created TIMESTAMPTZ DEFAULT NOW()\n"
        ");")


def test_spec_insert():
    assert sql("PUT users (name = 'Alex', email = 'alex@test.com')") == (
        "INSERT INTO users (name, email)\nVALUES ('Alex', 'alex@test.com');")


def test_spec_select():
    assert sql("GET name, email FROM users WHERE name = 'Alex' SORT created TOP 5") == (
        "SELECT name, email\nFROM users\nWHERE name = 'Alex'\nORDER BY created\nLIMIT 5;")


def test_spec_update():
    assert sql("PUT users (name = 'Alexander') WHERE email = 'alex@test.com'") == (
        "UPDATE users\nSET name = 'Alexander'\nWHERE email = 'alex@test.com';")


def test_spec_delete_and_drop_table():
    out = sql("DROP users WHERE name = 'Alex'\nDROP users")
    assert out == "DELETE FROM users WHERE name = 'Alex';\n\nDROP TABLE users;"


# ---- 2. Archivos de ejemplo: cada .msql genera su .sql (snapshot en expected/) -------
@pytest.mark.parametrize("path", EXAMPLES, ids=lambda p: p.name)
def test_examples_match_snapshot(path):
    got = compile_source(path.read_text(encoding="utf-8")).sql
    want = (ROOT / "expected" / (path.stem + ".sql")).read_text(encoding="utf-8")
    assert got == want


# ---- 3. Características del lenguaje ----------------------------------------------
def test_keywords_case_insensitive():
    assert sql("get ALL from t sort a desc top 3") == sql("GET ALL FROM t SORT a DESC TOP 3")


def test_double_quoted_strings_become_sql_strings():
    assert "'nobody@example.com'" in sql('GET id FROM u WHERE email <> "nobody@example.com"')


def test_quote_escaping():
    assert "'O''Brien'" in sql("PUT t (name = 'O''Brien')")


def test_not_equal_normalised():
    assert "a <> 1" in sql("GET ALL FROM t WHERE a != 1")


def test_negative_and_decimal_numbers():
    assert "price = -1.25" in sql("PUT t (price = -1.25) WHERE id = 1")


def test_or_inside_and_gets_parentheses():
    out = sql("GET ALL FROM t WHERE (a = 1 OR b = 2) AND c = 3")
    assert "WHERE (a = 1 OR b = 2) AND c = 3" in out


def test_and_binds_tighter_than_or():
    out = sql("GET ALL FROM t WHERE a = 1 OR b = 2 AND c = 3")
    assert "WHERE a = 1 OR b = 2 AND c = 3" in out


def test_null_comparisons():
    assert "a IS NULL" in sql("GET ALL FROM t WHERE a = null")
    assert "a IS NOT NULL" in sql("GET ALL FROM t WHERE a != null")
    assert "a IS NOT NULL" in sql("GET ALL FROM t WHERE a IS NOT NULL")


def test_comments_blank_lines_and_crlf():
    src = "-- cabecera\r\n\r\nDROP t   # fin\r\n\r\n# otro\r\nDROP u\r\n"
    assert sql(src) == "DROP TABLE t;\n\nDROP TABLE u;"


def test_empty_program():
    assert sql("") == ""


def test_identifier_that_starts_with_keyword():
    assert "FROM topsellers" in sql("GET ALL FROM topsellers")


def test_pg_reserved_identifier_is_quoted():
    assert 'FROM "user"' in sql("GET ALL FROM user")


# ---- 4. Errores ------------------------------------------------------------------
def errors(src, **kw):
    with pytest.raises(CompileError) as e:
        compile_source(src, header=False, **kw)
    return e.value.diagnostics


def test_syntax_error_has_line_and_column():
    d = errors("DROP t\nGET FROM t")[0]
    assert (d.line, d.phase) == (2, "léxico/sintáctico")


def test_all_syntax_errors_reported_at_once():
    ds = errors("GET FROM t\nPUT t (a 1)\nDROP ok\nMAKE (a text)")
    assert [d.line for d in ds] == [1, 2, 4]


def test_invalid_character():
    assert "carácter no válido" in errors("GET ALL FROM t WHERE a = @")[0].message


def test_reserved_word_as_identifier():
    d = errors("MAKE t (top num)")[0]
    assert "'top'" in d.message and "identificador" in d.message


def test_one_statement_per_line():
    errors("DROP a DROP b")


def test_unknown_type():
    assert "tipo desconocido" in errors("MAKE t (a string)")[0].message


def test_duplicate_column_and_two_ids():
    msgs = " | ".join(d.message for d in errors("MAKE t (a text, a num, i id, j id)"))
    assert "duplicado" in msgs and "solo puede tener una columna" in msgs


def test_duplicate_assignment():
    assert "más de una vez" in errors("PUT t (a = 1, a = 2)")[0].message


@pytest.mark.parametrize("n", ["1.5", "-3"])
def test_top_must_be_non_negative_integer(n):
    assert "TOP requiere un entero" in errors(f"GET ALL FROM t TOP {n}")[0].message


def test_warning_for_redundant_id_bang():
    r = compile_source("MAKE t (id id!)", header=False)
    assert r.warnings and "redundante" in r.warnings[0].message


# ---- 5. Modo estricto (validación contra el esquema) ----------------------------------
SCHEMA = "MAKE users (id id, email text!, active bool, age num, born time)\n"


def test_strict_ok_with_schema_in_same_file():
    sql(SCHEMA + "GET email FROM users WHERE active = true AND age >= 18", strict=True)


@pytest.mark.parametrize("stmt,needle", [
    ("GET ALL FROM nada", "no existe"),
    ("GET zzz FROM users", "no tiene el campo"),
    ("GET ALL FROM users WHERE age = 'x'", "se le da un valor 'text'"),
    ("PUT users (active = 1)", "se le da un valor 'num'"),
    ("PUT users (id = 5)", "GENERATED ALWAYS"),
    ("PUT users (email = null)", "NOT NULL"),
    ("GET ALL FROM users WHERE active > true", "solo admite"),
    ("GET ALL FROM users SORT zzz", "no tiene el campo"),
])
def test_strict_errors(stmt, needle):
    assert any(needle in d.message for d in errors(SCHEMA + stmt, strict=True))


def test_strict_drop_table_removes_it_from_catalog():
    assert any("no existe" in d.message for d in errors(SCHEMA + "DROP users\nGET ALL FROM users", strict=True))


def test_non_strict_does_not_need_schema():
    sql("GET whatever FROM anything")
