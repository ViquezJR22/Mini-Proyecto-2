# msqlc — Compilador de pseudolenguaje a PostgreSQL con Lark

Compilador escrito en Python que traduce un pseudolenguaje minimalista y orientado a líneas
(**MSQL**: `MAKE`, `GET`, `PUT`, `DROP`) a SQL estándar de PostgreSQL. El análisis léxico y sintáctico
lo hace [Lark](https://github.com/lark-parser/lark); el resto del *pipeline* (AST, análisis semántico y
generación de código) está en `msql/`.

> Mini proyecto — Ingeniería en Sistemas, UNADECA. Especificación: *Especificación del Pseudolenguaje PostgreSQL*.

## Instalación y uso

```bash
pip install -r requirements.txt            # solo necesita Lark (pytest para las pruebas)

python msqlc.py examples/schema.msql       # genera examples/schema.sql
python msqlc.py examples -o build          # compila todos los .msql de la carpeta -> build/*.sql
python msqlc.py examples/queries.msql --stdout
python msqlc.py examples/mutations.msql --strict            # valida tablas/campos/tipos contra los MAKE vistos
python msqlc.py examples/queries.msql --schema examples/schema.msql   # esquema en un archivo aparte
```

Cada archivo `.msql` genera un archivo `.sql`. Si hay errores no se escribe nada y el programa termina con
código 1; los mensajes indican archivo, línea, columna y la línea con un `^`.

```
entrada.msql:2:17: error (léxico/sintáctico): token inesperado 'x'; se esperaba '='
    PUT users (name 'x')
                    ^
```

## El lenguaje

| MSQL | PostgreSQL |
|---|---|
| `MAKE t (campo tipo[!], ...)` | `CREATE TABLE t (...)` |
| `GET campos\|ALL FROM t [WHERE c] [SORT campo [ASC\|DESC]] [TOP n]` | `SELECT ... FROM t [WHERE] [ORDER BY] [LIMIT]` |
| `PUT t (campo = valor, ...)` | `INSERT INTO t (...) VALUES (...)` |
| `PUT t (campo = valor, ...) WHERE c` | `UPDATE t SET ... WHERE c` |
| `DROP t WHERE c` | `DELETE FROM t WHERE c` |
| `DROP t` | `DROP TABLE t` |

**Tipos:** `id` → `BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY` · `num` → `NUMERIC` · `text` → `TEXT` ·
`bool` → `BOOLEAN DEFAULT FALSE` · `time` → `TIMESTAMPTZ DEFAULT NOW()`. Un `!` al final añade `NOT NULL`.

**Reglas léxicas:** una sentencia por línea, sin `;`; palabras clave sin distinguir mayúsculas
(`make` = `MAKE`); cadenas con `'...'` o `"..."` (se emiten siempre con comillas simples y `'` se escapa como `''`);
números con signo y decimales (`-1.25`); comentarios `-- ...` y `# ...`.

**Condiciones:** `=  !=  <>  <  >  <=  >=`, `AND`, `OR`, `NOT`, paréntesis, `IS [NOT] NULL`. Precedencia `NOT > AND > OR`.
`campo = NULL` se traduce a `campo IS NULL` (en SQL `= NULL` nunca es verdadero).

### Ejemplo

```
MAKE users (id id, email text!, display_name text, active bool, created_at time)
GET email, display_name FROM users WHERE active = true SORT created_at DESC TOP 20
PUT users (active = false) WHERE email = 'sam@example.com'
DROP users
```

```sql
CREATE TABLE users (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  email TEXT NOT NULL,
  display_name TEXT,
  active BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

SELECT email, display_name
FROM users
WHERE active = TRUE
ORDER BY created_at DESC
LIMIT 20;

UPDATE users
SET active = FALSE
WHERE email = 'sam@example.com';

DROP TABLE users;
```

## Arquitectura

```
 texto .msql ──► [1] Lark: lexer + parser LALR(1)  ──► parse tree        msql/grammar.lark, msql/parser.py
                 [2] AstBuilder (Transformer)      ──► AST tipado        msql/ast_nodes.py
                 [3] Analyzer (semántico)          ──► diagnósticos      msql/semantic.py
                 [4] Generador de código           ──► texto SQL         msql/codegen.py
```

* **`grammar.lark`** — gramática completa en EBNF de Lark: terminales con `/make\b/i` (sin distinguir mayúsculas
  y sin partir identificadores como `topsellers`) y reglas para las cuatro sentencias y las condiciones.
* **`parser.py`** — construye el parser (`lalr`, lexer `basic`, `propagate_positions`) y el `Transformer`
  que produce el AST. Si hay errores sintácticos, re‑parsea línea a línea para informar **todos** a la vez.
* **`semantic.py`** — siempre: tipos válidos, columnas duplicadas, una sola columna `id`, campos repetidos en
  `PUT`, `TOP` entero ≥ 0. Con `--strict`: tablas y campos existentes, tipos de los valores compatibles con los
  de la columna, `id` no asignable, `NULL` solo en columnas sin `!`, `DROP t` retira la tabla del catálogo.
* **`codegen.py`** — mapeo de tipos, formato de las sentencias, paréntesis solo cuando la precedencia lo
  exige, cita identificadores que sean palabras reservadas de PostgreSQL (p. ej. `user` → `"user"`).

## Verificación

```bash
python -m pytest -v        # 45 pruebas
```

Las pruebas cubren los 5 ejemplos de la especificación (salida exacta), los 6 archivos de `examples/`
(comparados contra `expected/*.sql`), características del lenguaje, errores léxicos/sintácticos/semánticos y
el modo estricto. Además, el SQL de `expected/` se validó con `pglast` (el parser real de PostgreSQL):
las 19 sentencias generadas son sintácticamente válidas.

```
examples/*.msql  ──msqlc──►  expected/*.sql
schema · queries · mutations · conditions · keyword-case · types
```

## Estructura

```
msqlc.py            punto de entrada
msql/               paquete del compilador (grammar.lark, parser, ast_nodes, semantic, codegen, compiler, cli, errors)
examples/           programas .msql de verificación
expected/           SQL generado por cada ejemplo
tests/              pruebas con pytest
```
