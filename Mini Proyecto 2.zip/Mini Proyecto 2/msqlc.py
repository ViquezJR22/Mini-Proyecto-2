#!/usr/bin/env python3
"""Punto de entrada:  python msqlc.py examples/ -o build/"""
import sys

from msql.cli import main

if __name__ == "__main__":
    sys.exit(main())
