"""Fase léxica + sintáctica, construida sobre Lark.

Flujo:   texto fuente --(Lark LALR + lexer básico)--> parse tree
         parse tree --(AstBuilder, un Transformer)--------> AST tipado
"""
from __future__ import annotations

from pathlib import Path
from typing import List, Optional, Tuple

from lark import Lark, Token, Transformer, v_args
from lark.exceptions import (UnexpectedCharacters, UnexpectedEOF,
                             UnexpectedInput, UnexpectedToken)

from . import ast_nodes as ast
from .errors import CompileError, Diagnostic

GRAMMAR_PATH = Path(__file__).with_name("grammar.lark")

# Palabras reservadas del pseudolenguaje: no pueden usarse como identificadores.
RESERVED = {
    "make", "get", "put", "drop", "from", "where", "sort", "top", "all",
    "and", "or", "not", "is", "true", "false", "null", "asc", "desc",
}

# Nombres legibles para los mensajes de "se esperaba ...".
_TOKEN_NAMES = {
    "NAME": "un identificador", "NUMBER": "un número", "STRING": "una cadena de texto",
    "LPAR": "'('", "RPAR": "')'", "COMMA": "','", "EQUAL": "'='",
    "COMP_OP": "un operador de comparación (<>, !=, <, >, <=, >=)",
    "NOT_NULL": "'!'", "ORDER_DIR": "ASC o DESC", "_NL": "fin de línea", "$END": "fin de línea",
}


def build_parser() -> Lark:
    return Lark.open(
        str(GRAMMAR_PATH),
        parser="lalr",
        lexer="basic",
        propagate_positions=True,
        maybe_placeholders=True,
    )


_PARSER: Optional[Lark] = None


def get_parser() -> Lark:
    global _PARSER
    if _PARSER is None:
        _PARSER = build_parser()
    return _PARSER


def _pos(meta) -> ast.Pos:
    return ast.Pos(getattr(meta, "line", 1) or 1, getattr(meta, "column", 1) or 1)


def _tpos(tok: Token) -> ast.Pos:
    return ast.Pos(tok.line, tok.column)


_ALL = object()  # marcador para GET ALL


@v_args(inline=True)
class AstBuilder(Transformer):
    """Convierte el parse tree de Lark en el AST de ``ast_nodes``."""

    def __init__(self):
        super().__init__(visit_tokens=True)
        self.diagnostics: List[Diagnostic] = []

    # ---- tokens -------------------------------------------------------
    def NAME(self, tok: Token) -> Token:
        if tok.value.lower() in RESERVED:
            self.diagnostics.append(Diagnostic(
                "error", f"'{tok.value}' es una palabra reservada y no puede usarse como identificador",
                tok.line, tok.column, phase="sintáctico"))
        return tok

    # ---- programa -----------------------------------------------------
    @v_args(inline=False)
    def start(self, children):
        return ast.Program([c for c in children if not isinstance(c, Token)])

    # ---- MAKE ---------------------------------------------------------
    @v_args(inline=False, meta=True)
    def make(self, meta, ch):
        _kw, table, *cols = ch
        return ast.Make(str(table), list(cols), _pos(meta))

    @v_args(inline=False, meta=True)
    def column(self, meta, ch):
        name, type_tok, bang = ch
        return ast.ColumnDef(str(name), str(type_tok).lower(), bang is not None,
                             _tpos(name), _tpos(type_tok))

    # ---- GET ----------------------------------------------------------
    def all_fields(self, _tok):
        return _ALL

    @v_args(inline=False)
    def field_list(self, names):
        return [str(n) for n in names]

    def sort(self, _kw, name, direction):
        return (str(name), direction is not None and str(direction).lower() == "desc")

    def top(self, kw, number):
        return (str(number), _tpos(number))

    @v_args(inline=False, meta=True)
    def get(self, meta, ch):
        _kw, fields, _from, table, where, sort, top = ch
        return ast.Get(
            table=str(table),
            fields=None if fields is _ALL else fields,
            where=where,
            sort=sort[0] if sort else None,
            sort_desc=bool(sort and sort[1]),
            top=top[0] if top else None,
            pos=_pos(meta),
            top_pos=top[1] if top else None,
        )

    # ---- PUT ----------------------------------------------------------
    @v_args(inline=False, meta=True)
    def assignment(self, meta, ch):
        name, _eq, value = ch
        return ast.Assignment(str(name), value, _tpos(name))

    @v_args(inline=False, meta=True)
    def put(self, meta, ch):
        _kw, table, *rest = ch
        where = rest.pop()                      # [where] siempre es el último hijo
        return ast.Put(str(table), rest, where, _pos(meta))

    # ---- DROP ---------------------------------------------------------
    @v_args(inline=False, meta=True)
    def drop(self, meta, ch):
        _kw, table, where = ch
        return ast.Drop(str(table), where, _pos(meta))

    # ---- WHERE / condiciones -----------------------------------------
    def where(self, _kw, condition):
        return condition

    @v_args(inline=False, meta=True)
    def or_(self, meta, ch):
        return ast.BoolOp("OR", ch[0], ch[2], _pos(meta))

    @v_args(inline=False, meta=True)
    def and_(self, meta, ch):
        return ast.BoolOp("AND", ch[0], ch[2], _pos(meta))

    @v_args(inline=False, meta=True)
    def not_(self, meta, ch):
        return ast.Not(ch[1], _pos(meta))

    @v_args(inline=False, meta=True)
    def compare(self, meta, ch):
        name, op, right = ch
        op = "<>" if str(op) == "!=" else str(op)
        return ast.Compare(str(name), op, right, _pos(meta))

    @v_args(inline=False, meta=True)
    def is_null(self, meta, ch):
        name, _is, not_tok, _null = ch
        return ast.IsNull(str(name), not_tok is not None, _pos(meta))

    # ---- operandos y literales ---------------------------------------
    def column_ref(self, name):
        return ast.ColumnRef(str(name), _tpos(name))

    def number(self, tok):
        return ast.Literal("num", str(tok), _tpos(tok))

    def string(self, tok):
        raw = str(tok)
        quote = raw[0]
        body = raw[1:-1].replace(quote * 2, quote)   # '' -> '   ""  -> "
        return ast.Literal("text", body, _tpos(tok))

    def true(self, tok):
        return ast.Literal("bool", True, _tpos(tok))

    def false(self, tok):
        return ast.Literal("bool", False, _tpos(tok))

    def null(self, tok):
        return ast.Literal("null", None, _tpos(tok))


# ---------------------------------------------------------------- errores
def _readable(terminals) -> str:
    names = []
    for t in sorted(terminals):
        label = _TOKEN_NAMES.get(t, t)
        if label not in names:
            names.append(label)
    return ", ".join(names[:6]) + ("…" if len(names) > 6 else "")


def _to_diagnostic(exc: UnexpectedInput, lines: List[str], line_offset: int = 0) -> Diagnostic:
    line = (exc.line or 1) + line_offset
    col = exc.column or 1
    src = lines[line - 1] if 0 < line <= len(lines) else None
    if isinstance(exc, UnexpectedEOF):
        msg = f"la sentencia termina antes de tiempo; se esperaba {_readable(exc.expected)}"
    elif isinstance(exc, UnexpectedToken):
        tok = exc.token
        shown = ("fin de línea" if tok.type in ("$END", "_NL")
                 else tok.value if tok.value[0] in "'\"" else f"'{tok.value}'")
        msg = f"token inesperado {shown}; se esperaba {_readable(exc.accepts or exc.expected)}"
    elif isinstance(exc, UnexpectedCharacters):
        msg = f"carácter no válido {exc.char!r}"
    else:  # pragma: no cover
        msg = str(exc)
    return Diagnostic("error", msg, line, col, src, phase="léxico/sintáctico")


def parse(source: str) -> Tuple[ast.Program, List[Diagnostic]]:
    """Parsea ``source``. Devuelve (AST, avisos de la fase sintáctica).

    Si hay errores sintácticos lanza ``CompileError`` con *todos* los errores
    (el lenguaje es orientado a líneas, así que cada línea se re‑parsea
    por separado para poder informar de varias a la vez).
    """
    parser = get_parser()
    lines = source.splitlines()
    try:
        tree = parser.parse(source)
    except UnexpectedInput:
        errors: List[Diagnostic] = []
        for i, text in enumerate(lines):
            if not text.strip():
                continue
            try:
                parser.parse(text)
            except UnexpectedInput as exc:
                errors.append(_to_diagnostic(exc, lines, line_offset=i))
        raise CompileError(errors or [Diagnostic("error", "error de sintaxis", 1)])

    builder = AstBuilder()
    program = builder.transform(tree)
    for d in builder.diagnostics:
        d.source_line = lines[d.line - 1] if 0 < d.line <= len(lines) else None
    errs = [d for d in builder.diagnostics if d.severity == "error"]
    if errs:
        raise CompileError(errs)
    return program, builder.diagnostics
