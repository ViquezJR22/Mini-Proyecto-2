"""Nodos del AST del pseudolenguaje MSQL.

El parser de Lark produce un árbol genérico; ``parser.AstBuilder`` lo
convierte en estas dataclasses tipadas, que son las que consumen el
análisis semántico y el generador de código.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Union


@dataclass(frozen=True)
class Pos:
    """Posición en el fuente (1-based)."""
    line: int
    column: int


# ------------------------------------------------------------------ valores
@dataclass
class Literal:
    kind: str            # "num" | "text" | "bool" | "null"
    value: object        # float/int-str, str, bool, None
    pos: Pos


@dataclass
class ColumnRef:
    name: str
    pos: Pos


Operand = Union[Literal, ColumnRef]


# -------------------------------------------------------------- condiciones
@dataclass
class Compare:
    column: str
    op: str              # normalizado: = <> < > <= >=
    right: Operand
    pos: Pos


@dataclass
class IsNull:
    column: str
    negated: bool
    pos: Pos


@dataclass
class BoolOp:
    op: str              # "AND" | "OR"
    left: "Condition"
    right: "Condition"
    pos: Pos


@dataclass
class Not:
    operand: "Condition"
    pos: Pos


Condition = Union[Compare, IsNull, BoolOp, Not]


# ---------------------------------------------------------------- sentencias
@dataclass
class ColumnDef:
    name: str
    type_name: str       # id | num | text | bool | time (en minúsculas)
    not_null: bool
    pos: Pos
    type_pos: Pos


@dataclass
class Make:
    table: str
    columns: List[ColumnDef]
    pos: Pos


@dataclass
class Get:
    table: str
    fields: Optional[List[str]]       # None  => ALL
    where: Optional[Condition]
    sort: Optional[str]
    sort_desc: bool
    top: Optional[str]                # texto del número; se valida en semántica
    pos: Pos
    top_pos: Optional[Pos] = None


@dataclass
class Assignment:
    column: str
    value: Literal
    pos: Pos


@dataclass
class Put:
    table: str
    assignments: List[Assignment]
    where: Optional[Condition]
    pos: Pos

    @property
    def is_update(self) -> bool:
        return self.where is not None


@dataclass
class Drop:
    table: str
    where: Optional[Condition]
    pos: Pos

    @property
    def is_delete(self) -> bool:
        return self.where is not None


Statement = Union[Make, Get, Put, Drop]


@dataclass
class Program:
    statements: List[Statement] = field(default_factory=list)
