"""Fase semántica.

Comprobaciones SIEMPRE activas (no necesitan conocer el esquema):
  * tipos de dato válidos en MAKE, sin columnas duplicadas, una sola columna ``id``
  * campos duplicados en PUT
  * TOP debe ser un entero >= 0
  * ``PUT`` no puede asignar la columna ``id`` (es GENERATED ALWAYS)  -- solo en --strict

Modo ``strict`` (opcional): construye un catálogo con los MAKE vistos (y/o un
archivo de esquema) y valida que tablas y campos existan y que los valores
literales sean compatibles con el tipo de la columna.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from . import ast_nodes as ast
from .errors import Diagnostic

VALID_TYPES = ("id", "num", "text", "bool", "time")

# tipo MSQL de columna -> tipos de literal aceptados
_ACCEPTS = {
    "id": {"num"},
    "num": {"num"},
    "text": {"text"},
    "bool": {"bool"},
    "time": {"text"},      # los timestamps se escriben como cadena ISO: '2026-10-29 10:00:00-06'
}


@dataclass
class TableInfo:
    columns: Dict[str, ast.ColumnDef] = field(default_factory=dict)


class Catalog:
    """Esquema conocido: tabla -> columnas."""

    def __init__(self) -> None:
        self.tables: Dict[str, TableInfo] = {}

    def add(self, make: ast.Make) -> None:
        self.tables[make.table.lower()] = TableInfo({c.name.lower(): c for c in make.columns})

    def drop(self, table: str) -> None:
        self.tables.pop(table.lower(), None)


class Analyzer:
    def __init__(self, source_lines: List[str], strict: bool = False,
                 catalog: Optional[Catalog] = None) -> None:
        self.lines = source_lines
        self.strict = strict
        self.catalog = catalog if catalog is not None else Catalog()
        self.diagnostics: List[Diagnostic] = []

    # ------------------------------------------------------------ utilidades
    def _report(self, severity: str, msg: str, pos: ast.Pos) -> None:
        src = self.lines[pos.line - 1] if 0 < pos.line <= len(self.lines) else None
        self.diagnostics.append(Diagnostic(severity, msg, pos.line, pos.column, src))

    def error(self, msg: str, pos: ast.Pos) -> None:
        self._report("error", msg, pos)

    def warn(self, msg: str, pos: ast.Pos) -> None:
        self._report("warning", msg, pos)

    # ------------------------------------------------------------- punto de entrada
    def analyze(self, program: ast.Program) -> List[Diagnostic]:
        for stmt in program.statements:
            getattr(self, "_" + type(stmt).__name__.lower())(stmt)
        return self.diagnostics

    # ----------------------------------------------------------------- MAKE
    def _make(self, s: ast.Make) -> None:
        seen: Dict[str, ast.ColumnDef] = {}
        id_cols = 0
        for col in s.columns:
            if col.type_name not in VALID_TYPES:
                self.error(f"tipo desconocido '{col.type_name}' para el campo '{col.name}' "
                           f"(tipos válidos: {', '.join(VALID_TYPES)})", col.type_pos)
            if col.name.lower() in seen:
                self.error(f"el campo '{col.name}' está duplicado en la tabla '{s.table}'", col.pos)
            seen[col.name.lower()] = col
            if col.type_name == "id":
                id_cols += 1
                if id_cols > 1:
                    self.error("una tabla solo puede tener una columna de tipo 'id' (clave primaria)", col.type_pos)
                if col.not_null:
                    self.warn("'id!' es redundante: la clave primaria ya es NOT NULL", col.type_pos)
        if self.strict and s.table.lower() in self.catalog.tables:
            self.error(f"la tabla '{s.table}' ya fue definida con MAKE", s.pos)
        self.catalog.add(s)

    # ------------------------------------------------------------------ GET
    def _get(self, s: ast.Get) -> None:
        info = self._table(s.table, s.pos)
        if s.fields is not None:
            for f in s.fields:
                self._column(info, s.table, f, s.pos)
        if s.sort is not None:
            self._column(info, s.table, s.sort, s.pos)
        if s.where is not None:
            self._condition(s.where, info, s.table)
        if s.top is not None and ("." in s.top or s.top.startswith("-")):
            self.error(f"TOP requiere un entero no negativo, se recibió '{s.top}'", s.top_pos or s.pos)

    # ------------------------------------------------------------------ PUT
    def _put(self, s: ast.Put) -> None:
        info = self._table(s.table, s.pos)
        seen = set()
        for a in s.assignments:
            if a.column.lower() in seen:
                self.error(f"el campo '{a.column}' se asigna más de una vez", a.pos)
            seen.add(a.column.lower())
            col = self._column(info, s.table, a.column, a.pos)
            if col is not None:
                if col.type_name == "id":
                    self.error(f"'{a.column}' es de tipo 'id' (GENERATED ALWAYS); no se puede asignar", a.pos)
                self._check_value(col, a.value, f"campo '{a.column}'")
        if s.where is not None:
            self._condition(s.where, info, s.table)

    # ----------------------------------------------------------------- DROP
    def _drop(self, s: ast.Drop) -> None:
        info = self._table(s.table, s.pos)
        if s.where is not None:
            self._condition(s.where, info, s.table)
        else:
            self.catalog.drop(s.table)

    # ----------------------------------------------------------- condiciones
    def _condition(self, c: ast.Condition, info: Optional[TableInfo], table: str) -> None:
        if isinstance(c, ast.BoolOp):
            self._condition(c.left, info, table)
            self._condition(c.right, info, table)
        elif isinstance(c, ast.Not):
            self._condition(c.operand, info, table)
        elif isinstance(c, ast.IsNull):
            self._column(info, table, c.column, c.pos)
        elif isinstance(c, ast.Compare):
            col = self._column(info, table, c.column, c.pos)
            r = c.right
            if isinstance(r, ast.ColumnRef):
                self._column(info, table, r.name, r.pos)
            elif col is not None:
                if r.kind == "null":
                    if c.op not in ("=", "<>"):
                        self.error("NULL solo puede compararse con '=' o '!=' (se traduce a IS [NOT] NULL)", r.pos)
                else:
                    self._check_value(col, r, f"campo '{c.column}'")
                    if col.type_name == "bool" and c.op not in ("=", "<>"):
                        self.error(f"el campo booleano '{c.column}' solo admite '=' y '!='", c.pos)

    # ------------------------------------------------- catálogo (modo strict)
    def _table(self, name: str, pos: ast.Pos) -> Optional[TableInfo]:
        info = self.catalog.tables.get(name.lower())
        if info is None and self.strict:
            self.error(f"la tabla '{name}' no existe (ni hay un MAKE previo)", pos)
        return info

    def _column(self, info: Optional[TableInfo], table: str, name: str, pos: ast.Pos) -> Optional[ast.ColumnDef]:
        if info is None or not self.strict:
            return None
        col = info.columns.get(name.lower())
        if col is None:
            self.error(f"la tabla '{table}' no tiene el campo '{name}'", pos)
        return col

    def _check_value(self, col: ast.ColumnDef, lit: ast.Literal, what: str) -> None:
        if not self.strict:
            return
        if lit.kind == "null":
            if col.not_null or col.type_name == "id":
                self.error(f"{what} es NOT NULL; no admite NULL", lit.pos)
            return
        if col.type_name not in VALID_TYPES:
            return
        if lit.kind not in _ACCEPTS[col.type_name]:
            self.error(f"{what} es de tipo '{col.type_name}' pero se le da un valor '{lit.kind}'", lit.pos)
