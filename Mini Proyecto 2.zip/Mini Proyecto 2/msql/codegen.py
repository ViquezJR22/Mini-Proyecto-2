"""Generación de código: AST -> PostgreSQL."""
from __future__ import annotations

from typing import List

from . import ast_nodes as ast

# Mapeo de tipos del pseudolenguaje -> PostgreSQL (sección 3 de la especificación)
TYPE_MAP = {
    "id":   "BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY",
    "num":  "NUMERIC",
    "text": "TEXT",
    "bool": "BOOLEAN DEFAULT FALSE",
    "time": "TIMESTAMPTZ DEFAULT NOW()",
}

# Palabras reservadas de PostgreSQL que, si se usan como identificador, deben ir entre comillas dobles.
PG_RESERVED = {
    "all", "analyse", "analyze", "and", "any", "array", "as", "asc", "asymmetric", "both", "case", "cast",
    "check", "collate", "column", "constraint", "create", "current_date", "current_time", "current_timestamp",
    "current_user", "default", "deferrable", "desc", "distinct", "do", "else", "end", "except", "false",
    "fetch", "for", "foreign", "from", "grant", "group", "having", "in", "initially", "intersect", "into",
    "leading", "limit", "localtime", "localtimestamp", "not", "null", "offset", "on", "only", "or", "order",
    "placing", "primary", "references", "returning", "select", "session_user", "some", "symmetric", "table",
    "then", "to", "trailing", "true", "union", "unique", "user", "using", "variadic", "when", "where",
    "window", "with",
}

_INDENT = "  "


def ident(name: str) -> str:
    """Identificador listo para PostgreSQL (se cita solo si es palabra reservada)."""
    return f'"{name}"' if name.lower() in PG_RESERVED else name


def literal(lit: ast.Literal) -> str:
    if lit.kind == "text":
        return "'" + str(lit.value).replace("'", "''") + "'"
    if lit.kind == "bool":
        return "TRUE" if lit.value else "FALSE"
    if lit.kind == "null":
        return "NULL"
    return str(lit.value)                        # num: se conserva tal cual (12.50, -1.25)


def condition(c: ast.Condition, parent: str = "") -> str:
    """Serializa una condición. Los paréntesis se emiten solo si la precedencia lo exige."""
    if isinstance(c, ast.BoolOp):
        text = f"{condition(c.left, c.op)} {c.op} {condition(c.right, c.op)}"
        return f"({text})" if parent == "AND" and c.op == "OR" else text
    if isinstance(c, ast.Not):
        inner = condition(c.operand, "NOT")
        if isinstance(c.operand, ast.BoolOp):
            inner = f"({inner})"
        return f"NOT {inner}"
    if isinstance(c, ast.IsNull):
        return f"{ident(c.column)} IS {'NOT ' if c.negated else ''}NULL"
    # Compare
    left = ident(c.column)
    r = c.right
    if isinstance(r, ast.Literal) and r.kind == "null":       # x = NULL  ->  x IS NULL
        return f"{left} IS {'NOT ' if c.op == '<>' else ''}NULL"
    right = ident(r.name) if isinstance(r, ast.ColumnRef) else literal(r)
    return f"{left} {c.op} {right}"


def _col_def(col: ast.ColumnDef) -> str:
    sql = f"{ident(col.name)} {TYPE_MAP.get(col.type_name, col.type_name.upper())}"
    if col.not_null and col.type_name != "id":    # la PRIMARY KEY ya implica NOT NULL
        sql += " NOT NULL"
    return sql


def gen_make(s: ast.Make) -> str:
    cols = (",\n").join(_INDENT + _col_def(c) for c in s.columns)
    return f"CREATE TABLE {ident(s.table)} (\n{cols}\n);"


def gen_get(s: ast.Get) -> str:
    fields = "*" if s.fields is None else ", ".join(ident(f) for f in s.fields)
    parts = [f"SELECT {fields}", f"FROM {ident(s.table)}"]
    if s.where is not None:
        parts.append(f"WHERE {condition(s.where)}")
    if s.sort is not None:
        parts.append(f"ORDER BY {ident(s.sort)}" + (" DESC" if s.sort_desc else ""))
    if s.top is not None:
        parts.append(f"LIMIT {int(s.top)}")
    return "\n".join(parts) + ";"


def gen_put(s: ast.Put) -> str:
    if not s.is_update:
        cols = ", ".join(ident(a.column) for a in s.assignments)
        vals = ", ".join(literal(a.value) for a in s.assignments)
        return f"INSERT INTO {ident(s.table)} ({cols})\nVALUES ({vals});"
    sets = ",\n    ".join(f"{ident(a.column)} = {literal(a.value)}" for a in s.assignments)
    return f"UPDATE {ident(s.table)}\nSET {sets}\nWHERE {condition(s.where)};"


def gen_drop(s: ast.Drop) -> str:
    if s.is_delete:
        return f"DELETE FROM {ident(s.table)} WHERE {condition(s.where)};"
    return f"DROP TABLE {ident(s.table)};"


_DISPATCH = {ast.Make: gen_make, ast.Get: gen_get, ast.Put: gen_put, ast.Drop: gen_drop}


def generate(program: ast.Program) -> List[str]:
    """Devuelve una sentencia SQL (ya terminada en ';') por cada sentencia MSQL."""
    return [_DISPATCH[type(s)](s) for s in program.statements]
