"""API pública: texto MSQL -> texto SQL (PostgreSQL)."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

from . import codegen
from .errors import CompileError, Diagnostic
from .parser import parse
from .semantic import Analyzer, Catalog

HEADER = "-- Generado por msqlc (MSQL -> PostgreSQL). No editar a mano."


@dataclass
class Result:
    sql: str
    warnings: List[Diagnostic] = field(default_factory=list)


def load_catalog(schema_source: str) -> Catalog:
    """Construye un catálogo a partir de un archivo de esquema (sentencias MAKE)."""
    program, _ = parse(schema_source)
    catalog = Catalog()
    from . import ast_nodes as ast
    for s in program.statements:
        if isinstance(s, ast.Make):
            catalog.add(s)
    return catalog


def compile_source(source: str, *, strict: bool = False, catalog: Optional[Catalog] = None,
                   header: bool = True) -> Result:
    """Compila ``source``. Lanza ``CompileError`` si hay errores léxicos, sintácticos o semánticos."""
    program, _ = parse(source)                                     # fases 1-2: léxico + sintáctico
    diags = Analyzer(source.splitlines(), strict=strict,           # fase 3: semántico
                     catalog=catalog).analyze(program)
    errors = [d for d in diags if d.severity == "error"]
    if errors:
        raise CompileError(errors)
    statements = codegen.generate(program)                         # fase 4: generación de código
    body = "\n\n".join(statements)
    sql = (HEADER + "\n\n" if header else "") + (body + "\n" if body else "")
    return Result(sql, [d for d in diags if d.severity == "warning"])
