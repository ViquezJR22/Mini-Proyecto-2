"""MSQL: pseudolenguaje orientado a líneas que se compila a PostgreSQL con Lark."""
from .compiler import compile_source, load_catalog  # noqa: F401
from .errors import CompileError  # noqa: F401

__version__ = "1.0.0"
