"""Interfaz de línea de comandos:  python msqlc.py <archivo.msql | carpeta> [opciones]"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import List

from .compiler import compile_source, load_catalog
from .errors import CompileError

EXT = ".msql"


def _collect(inputs: List[str]) -> List[Path]:
    files: List[Path] = []
    for raw in inputs:
        p = Path(raw)
        if p.is_dir():
            files.extend(sorted(p.glob(f"*{EXT}")))
        else:
            files.append(p)
    return files


def main(argv: List[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        prog="msqlc", description="Compilador MSQL -> PostgreSQL (construido con Lark).")
    ap.add_argument("inputs", nargs="+", help="archivos .msql o carpetas que los contengan")
    ap.add_argument("-o", "--out", help="carpeta de salida (por defecto, junto a cada archivo de entrada)")
    ap.add_argument("--stdout", action="store_true", help="imprimir el SQL en pantalla en vez de escribir archivos")
    ap.add_argument("--strict", action="store_true",
                    help="validar tablas, campos y tipos de valores contra los MAKE vistos")
    ap.add_argument("--schema", help="archivo .msql con los MAKE que definen el esquema (implica --strict)")
    ap.add_argument("--no-header", action="store_true", help="no escribir el comentario de cabecera")
    args = ap.parse_args(argv)

    strict = args.strict or bool(args.schema)
    files = _collect(args.inputs)
    if not files:
        print("msqlc: no se encontraron archivos .msql", file=sys.stderr)
        return 2

    base_catalog_src = Path(args.schema).read_text(encoding="utf-8") if args.schema else None
    out_dir = Path(args.out) if args.out else None
    if out_dir:
        out_dir.mkdir(parents=True, exist_ok=True)

    failed = 0
    for path in files:
        try:
            source = path.read_text(encoding="utf-8")
        except OSError as e:
            print(f"msqlc: no se pudo leer {path}: {e}", file=sys.stderr)
            failed += 1
            continue
        try:
            catalog = load_catalog(base_catalog_src) if base_catalog_src else None
            result = compile_source(source, strict=strict, catalog=catalog, header=not args.no_header)
        except CompileError as e:
            for d in e.diagnostics:
                print(d.format(str(path)), file=sys.stderr)
            print(f"msqlc: {path}: {len(e.diagnostics)} error(es); no se generó SQL", file=sys.stderr)
            failed += 1
            continue

        for w in result.warnings:
            print(w.format(str(path)), file=sys.stderr)
        if args.stdout:
            print(f"-- ===== {path.name} =====")
            print(result.sql, end="")
        else:
            target = (out_dir or path.parent) / (path.stem + ".sql")
            target.write_text(result.sql, encoding="utf-8")
            print(f"{path}  ->  {target}")
    return 1 if failed else 0


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
