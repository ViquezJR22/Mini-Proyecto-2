"""Errores y diagnósticos del compilador (mensajes en español)."""
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional


@dataclass
class Diagnostic:
    severity: str            # "error" | "warning"
    message: str
    line: int
    column: int = 1
    source_line: Optional[str] = None
    phase: str = "semántico"  # "léxico/sintáctico" | "semántico"

    def format(self, filename: str = "<entrada>") -> str:
        head = f"{filename}:{self.line}:{self.column}: {self.severity} ({self.phase}): {self.message}"
        if self.source_line is None:
            return head
        caret = " " * (max(self.column, 1) - 1) + "^"
        return f"{head}\n    {self.source_line}\n    {caret}"


class CompileError(Exception):
    """Se lanza cuando la compilación no puede completarse."""

    def __init__(self, diagnostics: List[Diagnostic]):
        self.diagnostics = diagnostics
        super().__init__("; ".join(d.message for d in diagnostics))
